# Prompt Book — CampusConnect Student Portal

Use these prompts in your AI tool and capture screenshots of the actual prompts and responses for the report. Do not claim screenshots or tests were completed unless you actually did them.

## 1. Idea / problem analysis
**Prompt:** I am a Semester 3 CSE student building an AI-assisted web application prototype for an end-semester exam. Suggest a simple Student Portal that helps students view academic information in one place. Define the problem statement, objective, target users, scope, and limitations. Keep it suitable for HTML, CSS, and JavaScript.

## 2. Requirements / features
**Prompt:** For a beginner Student Portal, define functional and non-functional requirements. Include a dashboard, subject-wise attendance, sample marks, timetable, notices, and tasks that users can add, complete, and delete. Save tasks using browser localStorage. Clearly state that this prototype uses demo data and has no real authentication or backend.

## 3. UI / layout design
**Prompt:** Design a modern responsive Student Portal called CampusConnect using plain HTML, CSS, and JavaScript. Use sidebar navigation, a student profile, welcome banner, academic statistic cards, timetable preview, notices, and separate Attendance, Marks, Timetable, and Tasks pages. Use accessible contrast, mobile-friendly CSS, and no framework.

## 4. Code generation
**Prompt:** Generate a complete beginner-friendly Student Portal in three files: index.html, style.css, and script.js. Include navigation across Dashboard, Attendance, Marks, Timetable, and Tasks & Notices; attendance bars; sample marks; timetable; add/complete/delete tasks saved in localStorage; and a dark-mode toggle. Use safe DOM text insertion for user-entered task text and responsive styling. Explain how to run it locally.

## 5. Testing
**Prompt:** Create a manual test plan for my HTML/CSS/JavaScript Student Portal. Include test ID, action, expected result, and pass/fail field. Test navigation, attendance, marks, timetable, adding tasks, completing tasks, deleting tasks, persistence after refresh, dark mode, and mobile responsiveness. Include empty input and long task names as edge cases.

## 6. Debugging / improvement
**Prompt:** Review my Student Portal code for broken navigation, unsafe rendering of user-entered tasks, localStorage parsing issues, and mobile layout problems. Suggest minimal fixes without frameworks or backend. Explain each fix simply and provide corrected code for affected sections only.

## 7. Final review / reflection
**Prompt:** Help me write a truthful reflection for my AI-assisted Student Portal. Explain how prompts supported idea analysis, requirements, UI planning, code generation, testing, and improvement. Separate implemented features from future improvements. Mention that academic values are sample data and the current version has no real authentication or university-system connection.
