# CampusConnect Student Portal — ESE Prototype

## Run
Open `student-portal/index.html` in a modern browser. No installation is required.

## Features
- Dashboard, Attendance, Marks, Timetable, Tasks & Notices
- Add, complete and delete tasks; task list saved in browser localStorage
- Responsive layout and dark-mode toggle
- Illustrative demo data only; no real login, backend, or official university records

## Publish for a working link
1. Create a GitHub repository (for example, `student-portal`).
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. Go to Settings → Pages → Deploy from a branch → choose `main` and `/ (root)` → Save.
4. Wait for the URL shown by GitHub Pages, open it in a private/incognito window, and test all features.
5. Use that verified URL in your report and Google Form. Do not submit an invented URL.
